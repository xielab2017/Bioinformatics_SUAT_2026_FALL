#!/usr/bin/env bash
set -euo pipefail
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
PLATFORM="${1:-agents}"
case "$PLATFORM" in
  codex) DEST="$HOME/.codex/skills/research-ai-suite" ;;
  claude|claude-code) DEST="$HOME/.claude/skills/research-ai-suite" ;;
  agents|cursor|generic) DEST="$HOME/.agents/skills/research-ai-suite" ;;
  *) echo "Usage: $0 [codex|claude|agents|cursor|generic]"; exit 2 ;;
esac
mkdir -p "$(dirname "$DEST")"
rm -rf "$DEST"
cp -R "$SRC" "$DEST"
python3 "$DEST/scripts/verify_install.py" "$DEST"
echo "Installed to: $DEST"
echo "Open a new agent session and ask: Use research-ai-suite ..."
