#!/usr/bin/env python3
from pathlib import Path
import argparse

parser = argparse.ArgumentParser()
parser.add_argument("path", nargs="?", default=".")
args = parser.parse_args()
root = Path(args.path).expanduser().resolve()
required = [
    "SKILL.md", "README.md", "SOURCES.md", "manifest.yaml", "source-lock.json",
    "references/platform-guide.md", "references/teaching-mode.md",
    "references/transcriptomics-example.md"
]
missing = [x for x in required if not (root / x).exists()]
if missing:
    print("FAIL: missing files")
    for x in missing:
        print(" -", x)
    raise SystemExit(1)
print("OK: research-ai-suite core files verified")
print("Path:", root)
