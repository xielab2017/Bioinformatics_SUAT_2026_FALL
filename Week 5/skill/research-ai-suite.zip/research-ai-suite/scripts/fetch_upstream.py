#!/usr/bin/env python3
"""Fetch pinned upstream repositories and optionally install selected skills.

This script is intentionally separate from the core bundle so third-party code remains
under its original license. It requires internet access on the user's machine.
"""
from __future__ import annotations
import argparse, json, os, shutil, tempfile, urllib.request, zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
LOCK = json.loads((ROOT / "source-lock.json").read_text())

PLATFORM_DEST = {
    "codex": Path.home() / ".codex" / "skills",
    "claude": Path.home() / ".claude" / "skills",
    "agents": Path.home() / ".agents" / "skills",
}

def download_repo(repo: str, commit: str, dest: Path) -> Path:
    url = f"https://github.com/{repo}/archive/{commit}.zip"
    dest.mkdir(parents=True, exist_ok=True)
    zip_path = dest / (repo.replace('/', '__') + f"__{commit[:12]}.zip")
    print(f"Downloading {repo}@{commit[:12]} ...")
    urllib.request.urlretrieve(url, zip_path)
    with zipfile.ZipFile(zip_path) as z:
        z.extractall(dest)
    top = next(p for p in dest.iterdir() if p.is_dir() and p.name.startswith(repo.split('/')[-1] + '-'))
    return top

def copy_skill(src: Path, rel: str, install_root: Path):
    s = src / rel
    if not s.exists():
        print("WARN missing upstream path:", s)
        return
    name = s.name
    d = install_root / name
    if d.exists(): shutil.rmtree(d)
    shutil.copytree(s, d)
    print("Installed", name, "->", d)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--platform', choices=['codex','claude','agents'], default='agents')
    ap.add_argument('--install', action='store_true')
    ap.add_argument('--vendor-dir', default=str(ROOT / 'vendor' / 'upstream'))
    args = ap.parse_args()
    vendor = Path(args.vendor_dir).expanduser().resolve()
    vendor.mkdir(parents=True, exist_ok=True)
    install_root = PLATFORM_DEST[args.platform]
    if args.install: install_root.mkdir(parents=True, exist_ok=True)

    for repo, spec in LOCK['repositories'].items():
        # ARS distributions are large and platform-specific; fetch them for inspection,
        # but install only the Codex suite into Codex or Claude folders explicitly below.
        repo_dir = download_repo(repo, spec['commit'], vendor / repo.replace('/', '__'))
        if not args.install:
            continue
        if repo == 'Imbad0202/academic-research-skills-codex':
            if args.platform == 'codex':
                copy_skill(repo_dir, 'skills/academic-research-suite', install_root)
            continue
        if repo == 'Imbad0202/academic-research-skills':
            if args.platform == 'claude':
                for rel in spec['skills']:
                    copy_skill(repo_dir, rel, install_root)
            continue
        for rel in spec['skills']:
            copy_skill(repo_dir, rel, install_root)

    print("Done. Upstream sources retained under:", vendor)
    if args.install: print("Skill install root:", install_root)

if __name__ == '__main__':
    main()
