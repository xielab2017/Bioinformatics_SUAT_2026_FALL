param(
  [ValidateSet('codex','claude','agents','cursor','generic')]
  [string]$Platform = 'agents'
)
$Src = Resolve-Path (Join-Path $PSScriptRoot '..')
$HomeDir = [Environment]::GetFolderPath('UserProfile')
switch ($Platform) {
  'codex'  { $Dest = Join-Path $HomeDir '.codex\skills\research-ai-suite' }
  'claude' { $Dest = Join-Path $HomeDir '.claude\skills\research-ai-suite' }
  default  { $Dest = Join-Path $HomeDir '.agents\skills\research-ai-suite' }
}
New-Item -ItemType Directory -Force -Path (Split-Path $Dest) | Out-Null
if (Test-Path $Dest) { Remove-Item -Recurse -Force $Dest }
Copy-Item -Recurse -Force $Src $Dest
python (Join-Path $Dest 'scripts\verify_install.py') $Dest
Write-Host "Installed to: $Dest"
