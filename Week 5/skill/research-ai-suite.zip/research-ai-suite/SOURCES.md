# Upstream sources and provenance

Assembled on **2026-09-17** from the user-provided GitHub skill index.

## Source index

| Stage | Skill | Repository/path | Purpose | License / boundary |
|---|---|---|---|---|
| Planning | Scientific Brainstorming | K-Dense-AI/scientific-agent-skills / `skills/scientific-brainstorming` | evidence-aware ideation, assumptions, hypotheses, decision log | MIT (skill metadata) |
| Literature | Nature Academic Search | Yuan1z0825/nature-skills / `skills/nature-academic-search` | multi-source search, citation verification, MeSH/reference workflows | repository Apache-2.0; inspect skill dependencies |
| Literature | Literature Review | K-Dense-AI/scientific-agent-skills / `skills/literature-review` | systematic search, screening, extraction, synthesis, citation verification | MIT (skill metadata) |
| Cross-stage | Academic Research Suite — Codex | Imbad0202/academic-research-skills-codex / `skills/academic-research-suite` | Codex-native full research workflow | CC BY-NC 4.0 repository license |
| Cross-stage | Academic Research Suite — Claude Code | Imbad0202/academic-research-skills | repository-native ARS workflow | inspect upstream license; do not assume commercial reuse |
| Statistics | Nature Statistics | Yuan1z0825/nature-skills / `skills/nature-statistics` | experimental unit, replication, p values, multiplicity, effect sizes, reporting | repository Apache-2.0; shared dependencies may apply |
| Figures | Scientific Visualization | K-Dense-AI/scientific-agent-skills / `skills/scientific-visualization` | truthful accessible publication figures | MIT (skill metadata) |
| Figures | Nature Figure | Yuan1z0825/nature-skills / `skills/nature-figure` | publication-grade R/Python figures and panel QA | repository Apache-2.0; shared dependencies may apply |
| Writing | Nature Writing | Yuan1z0825/nature-skills / `skills/nature-writing` | manuscript drafting | repository Apache-2.0; shared dependencies may apply |
| Writing | Nature Polishing | Yuan1z0825/nature-skills / `skills/nature-polishing` | academic English polishing and consistency | repository Apache-2.0; shared dependencies may apply |
| Submission | Nature Reviewer | Yuan1z0825/nature-skills / `skills/nature-reviewer` | simulated pre-submission review | repository Apache-2.0; shared dependencies may apply |
| Revision | Nature Response | Yuan1z0825/nature-skills / `skills/nature-response` | response-to-reviewers workflow | repository Apache-2.0; shared dependencies may apply |
| Data | Nature Data | Yuan1z0825/nature-skills / `skills/nature-data` | data availability and FAIR/repository planning | repository Apache-2.0; shared dependencies may apply |
| Presentation | Nature Paper2PPT | Yuan1z0825/nature-skills / `skills/nature-paper2ppt` | paper-to-PPT workflow | repository Apache-2.0; shared dependencies may apply |

## Repositories pinned at assembly time

- K-Dense-AI/scientific-agent-skills: `330c8e764435a731eff571e3efdda70b363d0792`
- Yuan1z0825/nature-skills: `2375e0abdf42158ef149256f2c64b1f759a0d274`
- Imbad0202/academic-research-skills-codex: `3c37ef8ab480ba1e9370309c24b99977ad44091f`
- Imbad0202/academic-research-skills: `3c546bc08c56f79e0068f1ea4f0acedf5bf69b5e`

## Important license note

This downloadable package is a **new orchestration layer**. It intentionally does not embed the complete ARS-Codex repository because ARS-Codex is licensed **CC BY-NC 4.0**. The provided fetch script can retrieve the upstream projects into a separate `vendor/` directory on the user's machine, preserving upstream licensing and attribution.

K-Dense notes that individual skills can carry skill-level licenses; verify the `license` field of any additional K-Dense skill before redistribution. The three K-Dense skills used here declare MIT in their skill metadata.
