# Platform installation and use

## 1. Codex / Codex Desktop

User-level install:

```bash
mkdir -p ~/.codex/skills
cp -R research-ai-suite ~/.codex/skills/research-ai-suite
```

Open a new Codex session and request:

```text
Use research-ai-suite to plan and execute this transcriptomics analysis with human checkpoints.
```

Optional upstream installs:

```bash
python3 ~/.codex/skills/research-ai-suite/scripts/fetch_upstream.py --platform codex --install
```

For ARS-Codex, upstream currently documents either a plugin install or direct `academic-research-suite` skill install. The helper script keeps it separate because of its license and runtime structure.

## 2. Claude Code

Simple skill-folder install:

```bash
mkdir -p ~/.claude/skills
cp -R research-ai-suite ~/.claude/skills/research-ai-suite
```

If your Claude Code build uses wrappers/subagents, use `adapters/claude-code.md` as the wrapper and point it at the real `SKILL.md`.

Optional upstream retrieval:

```bash
python3 ~/.claude/skills/research-ai-suite/scripts/fetch_upstream.py --platform claude --install
```

## 3. Cursor / Agent Skills-compatible hosts

Project-scoped:

```bash
mkdir -p .agents/skills
cp -R research-ai-suite .agents/skills/research-ai-suite
```

User-scoped shared location:

```bash
mkdir -p ~/.agents/skills
cp -R research-ai-suite ~/.agents/skills/research-ai-suite
```

Then tell the agent to read `research-ai-suite/SKILL.md` before acting.

## 4. Chatbox

1. Open **Settings → Skills**.
2. Open the local skills folder.
3. Copy the full `research-ai-suite` directory there.
4. Refresh/restart the skill list and enable the skill.
5. Use Agent Mode / a tool-capable model for tasks that require files, R, browser, or shell commands.

## 5. OpenClaw / OpenCode / Hermes / other agents

Use either:

- `~/.agents/skills/research-ai-suite`, or
- the host's documented project skill directory.

If the host does not natively parse `SKILL.md`, create a small wrapper that says:

```text
Before answering, read <path>/research-ai-suite/SKILL.md and follow it as the governing workflow. Load referenced files only when the current task requires them.
```

## 6. Plain ChatGPT / web chat without local skill loading

Upload the `SKILL.md` or the whole ZIP and say:

```text
Use the attached research-ai-suite as the governing workflow for this project.
```

For local code execution or automatic repository synchronization, use a coding-agent environment (Codex, Claude Code, Cursor, etc.).

## Dependencies

Installing a skill does **not** automatically install R, R packages, Python packages, browser tooling, MCP servers, or API credentials. Configure those only when the selected workflow needs them.
