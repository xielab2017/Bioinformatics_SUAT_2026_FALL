# Worked routing example — bulk RNA-seq / transcriptomics

## Goal

Compare control vs treatment and move from a count matrix to a testable biological hypothesis.

## Route

1. **Planning** — define tissue/cell model, treatment, independent replicate, contrast, RNA class.
2. **Literature** — verify known pathways and assay expectations; do not use literature to force the result.
3. **Design audit** — check batch balance, pairing, confounding, sample names, library type, strandedness.
4. **R analysis** — DESeq2 design, filtering, normalization, model, contrasts, LFC shrinkage.
5. **QC** — library size, mapping, PCA, sample distance, outliers.
6. **DE interpretation** — result table, MA, volcano, gene-level plots.
7. **Functional analysis** — ORA/GSEA, leading-edge genes, alternative explanations.
8. **Hypothesis** — convert enriched pathway + candidate genes into a falsifiable statement.
9. **Validation** — qPCR, perturbation, rescue, protein/functional assay as appropriate.
10. **Writing/review** — report design, effect size, uncertainty, limitations, and sources.

## Minimum R skeleton

```r
library(DESeq2)

counts <- read.csv("counts.csv", row.names = 1, check.names = FALSE)
meta   <- read.csv("metadata.csv", row.names = 1, check.names = FALSE)
stopifnot(identical(colnames(counts), rownames(meta)))

dds <- DESeqDataSetFromMatrix(
  countData = round(as.matrix(counts)),
  colData   = meta,
  design    = ~ batch + condition
)

dds <- dds[rowSums(counts(dds)) >= 10, ]
dds <- DESeq(dds)
resultsNames(dds)
res <- results(dds, contrast = c("condition", "Treated", "Control"))

vsd <- vst(dds, blind = FALSE)
plotPCA(vsd, intgroup = c("condition", "batch"))

sessionInfo()
```

Interpretation must be based on the actual result object and metadata, not on a generic expected biology.
