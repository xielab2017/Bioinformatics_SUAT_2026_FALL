# Teaching mode: AI without outsourcing scientific thinking

For undergraduate/graduate bioinformatics training, require four artifacts from the student:

1. **Before AI:** biological question + expected result + reason for assay/tool choice.
2. **During AI:** saved prompt/workflow and a record of which steps were AI-generated.
3. **After computation:** interpretation of at least one real table/figure in the student's own words.
4. **Reflection:** one alternative explanation, one limitation, and one validation experiment.

Suggested checkpoints for transcriptomics:

- What RNA class is being measured?
- Does the library strategy actually capture it?
- What is the independent replicate?
- Which metadata variables enter the design formula?
- Why are raw counts, TPM, and VST not interchangeable?
- What does PCA show, and what can it *not* prove?
- Why can a low-count gene show an extreme fold change?
- What is the difference between statistical significance and biological importance?
- What does ORA answer vs GSEA?
- What follow-up experiment would discriminate between two competing interpretations?
