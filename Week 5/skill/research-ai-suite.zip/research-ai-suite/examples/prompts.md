# Example prompts

## Full project

> Use `research-ai-suite`. First turn my problem into a precise biological question. Then audit the experimental design and metadata. Only after I confirm, plan literature search, R analysis, figures, biological interpretation, and validation. Keep a decision log and mark every AI-generated claim that still needs verification.

## Literature

> Use Block 2. Build a reproducible PubMed/Scholar search strategy, verify DOI/title/year for every included paper, group the literature by theme, and separate established evidence from open questions.

## RNA-seq

> Use Block 3 with R. Check whether raw counts and metadata are compatible, identify the correct DESeq2 design formula, generate PCA/MA/volcano/heatmap outputs, and explain what each plot can and cannot support.

## Writing

> Use Block 4. Draft a Results section only from the provided tables and figures. Do not add mechanisms that are not directly supported. Then run a terminology/unit/claim-strength consistency sweep.

## Pre-submission

> Use Block 5. Simulate a skeptical reviewer, identify major and minor issues, then create a point-by-point revision plan. Keep reviewer-style critique separate from author response drafting.
