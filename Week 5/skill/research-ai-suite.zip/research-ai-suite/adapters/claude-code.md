---
name: research-ai-suite
description: End-to-end human-in-the-loop academic research workflow and router.
---

Read the full `SKILL.md` in this directory first and follow it as the governing workflow.
Load files under `references/` only when relevant to the current task.
Prefer installed upstream specialist skills when the task clearly matches one.
Do not replace design checks, source verification, or statistical reasoning with a generic one-shot answer.
