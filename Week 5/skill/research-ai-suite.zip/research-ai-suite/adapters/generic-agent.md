# Generic Agent wrapper

Before acting, read `SKILL.md` and treat it as the governing workflow.

1. Classify the task into the five research blocks.
2. State the route.
3. Ask only for missing information that changes the analysis.
4. Use tools on real data/files when available.
5. Stop at human checkpoints before making high-level scientific claims.
6. Preserve provenance and provide reusable outputs.
