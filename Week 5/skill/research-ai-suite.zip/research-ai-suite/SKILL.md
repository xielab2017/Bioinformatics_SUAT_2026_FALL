---
name: research-ai-suite
description: >-
  Human-in-the-loop academic research orchestration skill that routes a project from
  question framing through literature discovery, statistics/visualization, manuscript
  writing, review/revision, data sharing, and presentation. Use when a user wants an
  end-to-end research workflow or needs one of the linked research skills coordinated.
  Prefer installed upstream skills when available; otherwise follow the bounded fallback
  workflows in this package. Never replace scientific judgment, source verification,
  experimental design, or statistical validity with generic AI output.
license: Mixed; this orchestration layer is newly assembled for the user. Third-party upstream skills retain their original licenses; see SOURCES.md.
metadata:
  version: "1.0.0"
  assembled: "2026-09-17"
  primary_language: "English with Chinese usage guide"
---

# Research AI Suite

## Purpose

Coordinate reusable research skills into one explainable workflow:

1. **Research planning** — turn an observation into a precise question, hypothesis, scope, and task plan.
2. **Literature discovery and synthesis** — search broadly, verify sources, organize evidence, and identify gaps.
3. **Statistical analysis and figure production** — inspect design/replication, run or audit analyses, and make truthful figures.
4. **Writing and language refinement** — draft evidence-grounded manuscript sections and polish academic language without changing meaning.
5. **Submission, revision, data sharing, and presentation** — simulate review, prepare responses, plan FAIR sharing, and convert papers/results into presentations.

A cross-stage **Academic Research Suite** may coordinate the full project when installed.

## Operating principle

AI may **plan, generate, run, audit, interpret, verify, and redesign**, but the scientist owns:

- the biological question;
- experimental unit, comparison, and covariates;
- evidence quality and source selection;
- statistical assumptions and inference boundaries;
- interpretation, causality claims, and mechanism;
- final writing, submission, and validation decisions.

At each stage, distinguish: **observation / evidence / assumption / interpretation / hypothesis / decision**.

## First action: classify the task

Map the request to one or more blocks:

| Block | Typical intent | Preferred upstream skills |
|---|---|---|
| 1. Planning | brainstorm, refine question, hypothesis, scope, project plan | `scientific-brainstorming`, Academic Research Suite |
| 2. Literature | search papers, verify DOI/citations, review/synthesize evidence | `nature-academic-search`, `literature-review` |
| 3. Analysis & figures | statistics audit, DE analysis, plots, publication figures | `nature-statistics`, `scientific-visualization`, `nature-figure` |
| 4. Writing | draft abstract/introduction/results/discussion, polish English | `nature-writing`, `nature-polishing` |
| 5. Submission & communication | reviewer simulation, response, data statement, paper-to-PPT | `nature-reviewer`, `nature-response`, `nature-data`, `nature-paper2ppt` |
| Cross-stage | coordinate a multi-step research project | Academic Research Suite (Codex or Claude Code edition) |

If multiple blocks are needed, state the route in one short line, e.g.:

`Route: Planning → Literature → Analysis/Figures → Writing → Review.`

## Universal workflow

### Step 1 — Define the scientific question

Before touching data or literature, capture:

- biological system and phenotype;
- comparison/contrast;
- experimental unit and sample structure;
- target molecule/data type;
- key covariates, batches, pairing, repeated measures;
- intended inference: description, association, prediction, mechanism, or intervention;
- expected deliverable.

**Human checkpoint:** Is the question specific, testable, and matched to the available evidence?

### Step 2 — Build the evidence base

Use installed literature skills when available. Otherwise:

1. formulate reproducible queries;
2. search multiple sources;
3. screen for relevance;
4. verify DOI/title/authors/year against the original source;
5. extract methods, cohort/system, result, limitations, and unresolved questions;
6. separate consensus from controversy and unknowns.

Never invent citations or infer a research gap only from a failed search.

**Human checkpoint:** Are the sources real, relevant, current enough, and appropriate to the claim?

### Step 3 — Audit experimental design before statistics

Record:

- independent experimental unit (`n`);
- biological vs technical replication;
- group balance and confounding;
- paired/repeated structure;
- exclusions and missing data;
- batch and covariate structure;
- primary comparison and multiplicity.

Do not treat cells, images, fields, repeated measurements, or technical replicates as independent biological replicates unless the design supports that inference.

**Human checkpoint:** Can the requested effect actually be estimated from the design?

### Step 4 — Analyze reproducibly

For transcriptomics and similar count-based omics, prefer a recorded script/workflow rather than copy-pasted one-off commands.

Minimum analysis packet:

- input files and checksums/identifiers;
- metadata/design table;
- software/package versions;
- preprocessing/QC decisions;
- statistical formula/contrast;
- normalization/transformation choice;
- result tables with effect size + uncertainty/significance;
- figures generated from saved result objects;
- `sessionInfo()` or equivalent environment record.

Use **R** for statistical workflows by default when the project is transcriptomic/omics and the user has not specified another language.

**Human checkpoint:** Do the counts/metadata/contrast match the biological question?

### Step 5 — Visualize without distorting evidence

Choose the plot by question, not by habit. Preserve raw data, missingness, units, transformations, sample structure, and uncertainty.

For common transcriptomic figures:

- PCA / distance: global sample structure, batch, outliers;
- MA: effect size vs abundance/uncertainty;
- volcano: effect size + statistical evidence, not mechanism;
- heatmap: selected features and scaling-dependent patterns;
- ORA/GSEA: pathway-level hypotheses, not proof;
- gene-level plot: candidate expression distribution and variability.

**Human checkpoint:** Does the figure faithfully represent the actual data and analysis object?

### Step 6 — Interpret biologically

Build an evidence ladder:

`statistical result → reproducible pattern → pathway/context → candidate mechanism → testable hypothesis → validation experiment`

Do not convert association into causality. State alternative explanations and contradictory evidence.

**Human checkpoint:** What evidence would falsify the interpretation?

### Step 7 — Draft and polish

Draft from the verified analysis packet, not from memory. Separate Results from Discussion. Keep numerical values, directions, sample sizes, gene/protein names, and conclusion boundaries stable during polishing.

Recommended order:

1. figure/result outline;
2. Results paragraphs;
3. Methods/statistics;
4. Introduction;
5. Discussion;
6. Abstract/title;
7. language polishing and consistency sweep.

**Human checkpoint:** Is every claim traceable to a figure, table, source, or explicitly labeled hypothesis?

### Step 8 — Review, response, data, and presentation

Before submission:

- run reviewer-style logic/method consistency checks;
- create point-by-point responses tied to revised text;
- prepare data/code availability statements and repository plan;
- verify references, figure legends, statistics, gene names, units, and version information;
- build teaching/presentation slides around the evidence chain rather than manuscript order.

**Human checkpoint:** Could an independent reader reproduce the reasoning and understand the limitations?

## Upstream skill routing

If an upstream skill is installed, prefer it for its specialization and use this suite as the router.

### Block 1 — Research planning

**`scientific-brainstorming`**
- independently generate candidate directions before convergence;
- label ideas, assumptions, predictions, evidence, and decisions;
- define evaluation criteria before ranking;
- preserve dissent, uncertainty, and negative evidence;
- treat brainstorming as proposal generation, never validation.

**Academic Research Suite**
- use for cross-stage project coordination, long-running research workflows, manuscript/reviewer loops, and task decomposition.

### Block 2 — Literature discovery and synthesis

**`nature-academic-search`**
- route among multi-source search, citation verification, MeSH strategy, citation-file management, reference management, and citation-impact audit;
- use source tiers and explicit fallback chains;
- verify identifiers and references before reuse.

**`literature-review`**
- planning/scoping;
- reproducible multi-database search;
- screening/selection;
- structured extraction/quality assessment;
- synthesis;
- citation verification;
- review document generation.

### Block 3 — Statistics and figure production

**`nature-statistics`**
- identify experimental unit and replication hierarchy;
- map claims to models/tests;
- check multiplicity, effect size, uncertainty, exact test definitions, and reporting completeness;
- flag missing information instead of inventing it.

**`scientific-visualization`**
- preserve data integrity and provenance;
- choose honest encodings;
- state uncertainty and `n`;
- use color redundantly and check accessibility;
- inspect final exported files, not only plotting code.

**`nature-figure`**
- use when a publication-grade final figure or multi-panel layout is required.

### Block 4 — Writing and language refinement

**`nature-writing`**
- draft structured manuscript sections from verified evidence and figures.

**`nature-polishing`**
- improve academic English, concision, terminology, units, and consistency;
- never strengthen claims or alter scientific meaning silently.

### Block 5 — Submission, revision, data sharing, presentation

**`nature-reviewer`** — pre-submission peer-review simulation and consistency audit.

**`nature-response`** — parse reviewer comments, draft point-by-point replies, and align responses with revised text.

**`nature-data`** — data availability statement, repository planning, FAIR-oriented checks.

**`nature-paper2ppt`** — convert a paper into a structured presentation with key figures, methods, and conclusions.

## Agent operating pattern

Use this loop for complex tasks:

1. **Plan** — define the question, inputs, constraints, and deliverables.
2. **Generate** — propose code, search queries, analyses, figures, or text.
3. **Run** — execute tools/code against real files/data.
4. **Audit** — inspect errors, assumptions, QC, metadata, and source provenance.
5. **Interpret** — summarize what the outputs support.
6. **Verify** — cross-check against data, documentation, and literature.
7. **Redesign** — refine the analysis or next experiment.

Do not skip `Audit` and `Verify` merely because code ran successfully.

## Teaching mode

When the user says this is for a class, homework, training, or student exercise:

- require the student to write the biological question before AI analysis;
- require a short rationale for assay/tool choice;
- ask the student to predict an expected result before running code;
- require interpretation of at least one real output (table or figure);
- ask for one alternative explanation and one validation experiment;
- record what AI generated vs what the student independently decided.

The goal is **AI-assisted reasoning**, not answer outsourcing.

## Deliverables

For a full project, produce an organized directory such as:

```text
project/
├── 00_question/
├── 01_literature/
├── 02_data_raw/
├── 03_metadata_design/
├── 04_code/
├── 05_results_tables/
├── 06_figures/
├── 07_interpretation/
├── 08_manuscript/
├── 09_review_response/
├── 10_data_release/
└── 11_presentation/
```

Every project should include `README.md`, provenance, package versions, and a human-readable decision log.

## Source and license boundary

This skill is an orchestration layer assembled from the user-provided index and public upstream documentation. It **does not relicense or replace** the upstream projects. Original upstream skills remain subject to their own licenses and dependencies. See `SOURCES.md` and `references/platform-guide.md`.
