# Research AI Suite — 科研全流程 AI/Agent Skill

这是一个把用户提供的科研 GitHub Skills 索引重新组织成**一个可调用、可教学、可复现的总控 Skill**。核心不是把 13 个技能简单堆在一起，而是按科研证据链路做路由：

**Research planning → Literature → Statistics/Figures → Writing → Review/Revision/Data/PPT**

同时保留一个跨阶段的 Academic Research Suite 作为全流程 coordinator。

## 主要特点

- 一个 `SKILL.md` 作为总入口；
- 5 个科研大模块 + 1 个跨阶段 coordinator；
- 人类检查点（human checkpoints）贯穿所有流程；
- 面向 transcriptomics / omics 时默认优先使用 R；
- 自带教学模式，避免学生把任务直接丢给 AI；
- 自带 Codex、Claude Code、Cursor/通用 Agent、Chatbox 使用指南；
- 自带 pinned upstream source lock 和一键抓取脚本；
- 不把第三方项目重新授权；各上游保留原始 license。

## 快速使用

安装后直接说：

```text
Use research-ai-suite to analyze this RNA-seq project from question framing to figures and interpretation.
```

或者：

```text
请使用 research-ai-suite。先检查我的生物学问题和实验设计，再决定文献检索、R 分析、绘图和结果解释的流程。每一步都保留 human checkpoint。
```

## 目录

- `SKILL.md`：总控路由与 fallback workflow
- `SOURCES.md`：上游技能、GitHub、固定版本和许可
- `references/`：模块细节、平台安装、转录组示例
- `scripts/`：安装、验证、可选上游抓取脚本
- `adapters/`：不同 Agent 平台 wrapper 示例
- `examples/`：常用提示词

详细安装见 `references/platform-guide.md`。
